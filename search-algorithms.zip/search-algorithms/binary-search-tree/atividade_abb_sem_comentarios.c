#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define REPETICOES 20000

typedef struct No {
    int valor;
    struct No *esquerda;
    struct No *direita;
} No;


No *criarNo(int valor) {
    No *novo = malloc(sizeof(No));
    if (novo == NULL) {
        fprintf(stderr, "Erro: memoria insuficiente.\n");
        exit(EXIT_FAILURE);
    }
    novo->valor = valor;
    novo->esquerda = NULL;
    novo->direita = NULL;
    return novo;
}



No *inserir(No *raiz, int valor) {
    if (raiz == NULL) {
        return criarNo(valor);
    }
    if (valor < raiz->valor) {
        raiz->esquerda = inserir(raiz->esquerda, valor);
    } else if (valor > raiz->valor) {
        raiz->direita = inserir(raiz->direita, valor);
    }
    return raiz;
}



int buscar(No *raiz, int procurado, long *comparacoes, int mostrarCaminho) {
    int primeiro = 1;
    while (raiz != NULL) {
        (*comparacoes)++;
        if (mostrarCaminho) {
            printf("%s%d", primeiro ? "" : " -> ", raiz->valor);
            primeiro = 0;
        }

        if (procurado == raiz->valor) {
            return 1;
        }
        if (procurado < raiz->valor) {
            raiz = raiz->esquerda;
        } else {
            raiz = raiz->direita;
        }
    }
    if (mostrarCaminho) {
        printf(" -> NULL");
    }
    return 0;
}


void imprimirEmOrdem(No *raiz) {
    if (raiz == NULL) return;
    imprimirEmOrdem(raiz->esquerda);
    printf("%d ", raiz->valor);
    imprimirEmOrdem(raiz->direita);
}


int altura(No *raiz) {
    if (raiz == NULL) return 0;
    int esq = altura(raiz->esquerda);
    int dir = altura(raiz->direita);
    return 1 + (esq > dir ? esq : dir);
}


void montarBalanceada(No **raiz, int inicio, int fim) {
    if (inicio > fim) return;
    int meio = inicio + (fim - inicio) / 2;
    *raiz = inserir(*raiz, meio);
    montarBalanceada(raiz, inicio, meio - 1);
    montarBalanceada(raiz, meio + 1, fim);
}


void liberarArvore(No *raiz) {
    if (raiz == NULL) return;
    liberarArvore(raiz->esquerda);
    liberarArvore(raiz->direita);
    free(raiz);
}


void medir(No *raiz, int numeroNos, const char *tipo) {
    int alvo = numeroNos + 1;
    long comparacoes = 0;
    int encontrados = 0;
    clock_t inicio = clock();

    for (int i = 0; i < REPETICOES; i++) {
        encontrados += buscar(raiz, alvo, &comparacoes, 0);
    }

    clock_t fim = clock();
    double tempoMs = (double)(fim - inicio) * 1000.0 / CLOCKS_PER_SEC;
    printf("%-14s | %6d nos | altura %5d | %8.1f comp./busca | %9.3f ms\n",
           tipo, numeroNos, altura(raiz),
           (double)comparacoes / REPETICOES, tempoMs);


    if (encontrados != 0) {
        printf("Aviso: o numero de teste deveria estar ausente.\n");
    }
}

void testeDeDesempenho(void) {
    const int tamanhos[] = {1000, 5000, 10000};
    printf("\n=== COMPARACAO DE DESEMPENHO DE ABBs ===\n");
    printf("Cada linha executa %d buscas por um numero ausente.\n", REPETICOES);
    printf("A construcao da arvore NAO entra no tempo medido.\n\n");

    for (int i = 0; i < 3; i++) {
        int n = tamanhos[i];
        No *balanceada = NULL;
        No *desbalanceada = NULL;

        montarBalanceada(&balanceada, 1, n);
        for (int valor = 1; valor <= n; valor++) {
            desbalanceada = inserir(desbalanceada, valor);
        }

        medir(balanceada, n, "Balanceada");
        medir(desbalanceada, n, "Desbalanceada");
        printf("\n");

        liberarArvore(balanceada);
        liberarArvore(desbalanceada);
    }
    printf("Observacao: tempos variam entre computadores e execucoes.\n");
}

int main(void) {

    const int valores[] = {50, 17, 76, 9, 23, 54, 14, 19, 72, 12, 67};
    const int quantidade = sizeof(valores) / sizeof(valores[0]);
    No *raiz = NULL;

    for (int i = 0; i < quantidade; i++) {
        raiz = inserir(raiz, valores[i]);
    }

    printf("ATIVIDADE: ARVORE BINARIA DE BUSCA (ABB)\n");
    printf("Arvore de exemplo: %d nos, altura de %d niveis, raiz %d.\n",
           quantidade, altura(raiz), raiz->valor);

    int opcao;
    do {
        printf("\n1 - Pesquisar numero na arvore do professor\n");
        printf("2 - Medir desempenho (balanceada x desbalanceada)\n");
        printf("3 - Mostrar valores em ordem crescente\n");
        printf("0 - Sair\nOpcao: ");

        if (scanf("%d", &opcao) != 1) {
            printf("Entrada invalida. Encerrando.\n");
            break;
        }

        if (opcao == 1) {
            int numero;
            printf("Numero procurado: ");
            if (scanf("%d", &numero) != 1) {
                printf("Entrada invalida. Encerrando.\n");
                break;
            }
            long comparacoes = 0;
            printf("Caminho: ");
            int encontrou = buscar(raiz, numero, &comparacoes, 1);
            printf("\nResultado: %s | Nos examinados: %ld\n",
                   encontrou ? "ENCONTRADO" : "NAO ENCONTRADO", comparacoes);
        } else if (opcao == 2) {
            testeDeDesempenho();
        } else if (opcao == 3) {
            printf("Percurso em ordem: ");
            imprimirEmOrdem(raiz);
            printf("\n");
        } else if (opcao != 0) {
            printf("Opcao desconhecida.\n");
        }
    } while (opcao != 0);

    liberarArvore(raiz);
    return 0;
}
