#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct No {
    int valor;
    struct No *esquerda;
    struct No *direita;
} No;

static No *inserir(No *raiz, int valor) {
    if (raiz == NULL) {
        No *novo = malloc(sizeof *novo);
        if (novo == NULL) {
            fprintf(stderr, "Falha ao alocar memoria.\n");
            exit(EXIT_FAILURE);
        }
        novo->valor = valor;
        novo->esquerda = NULL;
        novo->direita = NULL;
        return novo;
    }
    if (valor < raiz->valor)
        raiz->esquerda = inserir(raiz->esquerda, valor);
    else if (valor > raiz->valor)
        raiz->direita = inserir(raiz->direita, valor);
    return raiz;
}

static int busca_abb(const No *raiz, int chave, long *visitados, int exibir_caminho) {
    while (raiz != NULL) {
        ++(*visitados);
        if (exibir_caminho) printf("%d ", raiz->valor);
        if (chave == raiz->valor) return 1;
        raiz = (chave < raiz->valor) ? raiz->esquerda : raiz->direita;
    }
    return 0;
}

static int busca_sequencial(const int *vetor, int n, int chave, long *visitados) {
    for (int i = 0; i < n; i++) {
        ++(*visitados);
        if (vetor[i] == chave) return 1;
    }
    return 0;
}

static int busca_binaria(const int *vetor, int n, int chave, long *visitados) {
    int inicio = 0;
    int fim = n - 1;
    while (inicio <= fim) {
        int meio = inicio + (fim - inicio) / 2;
        ++(*visitados);
        if (vetor[meio] == chave) return 1;
        if (chave < vetor[meio]) fim = meio - 1;
        else inicio = meio + 1;
    }
    return 0;
}

static void liberar_abb(No *raiz) {
    if (raiz == NULL) return;
    liberar_abb(raiz->esquerda);
    liberar_abb(raiz->direita);
    free(raiz);
}

static void medir(const char *metodo, int tipo, const int *ordenado, int n,
                  const No *raiz, const int *consultas, int quantidade) {
    long long total_visitados = 0;
    int encontrados = 0;
    clock_t inicio = clock();
    for (int i = 0; i < quantidade; i++) {
        long visitados = 0;
        int achou;
        if (tipo == 0)
            achou = busca_sequencial(ordenado, n, consultas[i], &visitados);
        else if (tipo == 1)
            achou = busca_binaria(ordenado, n, consultas[i], &visitados);
        else
            achou = busca_abb(raiz, consultas[i], &visitados, 0);
        encontrados += achou;
        total_visitados += visitados;
    }
    double segundos = (double)(clock() - inicio) / CLOCKS_PER_SEC;
    printf("%-12s  %10.6f s  %12.2f  %8d\n", metodo, segundos,
           (double)total_visitados / quantidade, encontrados);
}

static void experimento(int n, int quantidade) {
    int *ordenado = malloc((size_t)n * sizeof *ordenado);
    int *embaralhado = malloc((size_t)n * sizeof *embaralhado);
    int *consultas = malloc((size_t)quantidade * sizeof *consultas);
    if (!ordenado || !embaralhado || !consultas) {
        fprintf(stderr, "Falha ao alocar vetores.\n");
        free(ordenado);
        free(embaralhado);
        free(consultas);
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < n; i++) {
        ordenado[i] = i;
        embaralhado[i] = i;
    }

    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int auxiliar = embaralhado[i];
        embaralhado[i] = embaralhado[j];
        embaralhado[j] = auxiliar;
    }
    No *raiz = NULL;
    for (int i = 0; i < n; i++) raiz = inserir(raiz, embaralhado[i]);


    for (int i = 0; i < quantidade; i++) {
        consultas[i] = (i % 2 == 0) ? rand() % n : n + rand() % n;
    }
    printf("\nN = %d valores | %d consultas (50%% presentes, 50%% ausentes)\n", n, quantidade);
    printf("Metodo           Tempo CPU      Media visitados  Achados\n");
    medir("Sequencial", 0, ordenado, n, raiz, consultas, quantidade);
    medir("Binaria", 1, ordenado, n, raiz, consultas, quantidade);
    medir("ABB", 2, ordenado, n, raiz, consultas, quantidade);

    liberar_abb(raiz);
    free(ordenado);
    free(embaralhado);
    free(consultas);
}

int main(void) {
    srand(42);


    const int valores[] = {50, 17, 76, 9, 23, 54, 14, 19, 72, 12, 67};
    No *exemplo = NULL;
    for (size_t i = 0; i < sizeof valores / sizeof valores[0]; i++)
        exemplo = inserir(exemplo, valores[i]);
    long visitados = 0;
    printf("Exemplo da imagem: pesquisa pelo valor 67\n");
    printf("Caminho: ");
    int achou = busca_abb(exemplo, 67, &visitados, 1);
    printf("\nResultado: %s | nos visitados: %ld\n", achou ? "encontrado" : "ausente", visitados);
    liberar_abb(exemplo);


    experimento(1000, 20000);
    experimento(10000, 20000);
    experimento(50000, 20000);
    return 0;
}
