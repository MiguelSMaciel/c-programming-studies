# Algoritmos de pesquisa em C

Exercícios de Estruturas de Dados. Cada exemplo possui duas versões:
- arquivo original: **código exatamente como entregue antes**, incluindo os comentários;
- arquivo `_sem_comentarios.c`: mesmo programa, mas sem comentários.

## Pastas

### `methods-comparison/`
`atividade_metodos_pesquisa.c` e `atividade_metodos_pesquisa_sem_comentarios.c`.

Compara **pesquisa sequencial**, **pesquisa binária** e **Árvore Binária de Busca (ABB)**. Usa a árvore do exercício como exemplo e realiza testes de desempenho com conjuntos maiores.

### `binary-search-tree/`
`atividade_abb.c` e `atividade_abb_sem_comentarios.c`.

Foca apenas na **ABB**: criação, inserção, pesquisa com caminho percorrido, percurso em ordem e testes comparando árvores balanceadas e desbalanceadas.

## Compilar e executar

Entre na pasta do exercício e compile apenas **uma versão de cada vez**, pois cada arquivo possui sua própria função `main`.

**Comparação de métodos** (dentro de `methods-comparison`):

```bash
gcc -std=c11 -O2 -Wall -Wextra atividade_metodos_pesquisa.c -o pesquisa
./pesquisa
```

**ABB** (dentro de `binary-search-tree`):

```bash
gcc -std=c11 -O2 -Wall -Wextra atividade_abb.c -o abb
./abb
```

No Windows, execute `pesquisa.exe` ou `abb.exe` em vez de `./pesquisa` ou `./abb`, se estiver usando PowerShell ou Prompt de Comando.

Para executar a versão sem comentários, basta substituir o nome do arquivo no comando de compilação.

**Observação:** o código original não foi modificado. Retirar os comentários não altera a lógica; os tempos medidos podem variar de uma máquina para outra.
